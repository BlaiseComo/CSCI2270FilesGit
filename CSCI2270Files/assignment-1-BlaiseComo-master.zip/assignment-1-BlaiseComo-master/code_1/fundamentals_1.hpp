#ifndef READFILE_H__
#define READFILE_H__

#include <string>
#include <iostream>
#include <fstream>

using namespace std;

// TODO add detailed explanation on what the function should do
// This function should take an array, the number of elements in the array, and a value to be inserted into the array. It should then add the new value to the array and sort the array 
int addToArrayDesc(float sortedArray[], int numElements, float newValue);

#endif // READFILE_H__