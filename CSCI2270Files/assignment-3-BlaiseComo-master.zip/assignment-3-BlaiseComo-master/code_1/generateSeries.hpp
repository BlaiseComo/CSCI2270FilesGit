#ifndef APPEND_H__
#define APPEND_H__
#include <string>
#include <iostream>
#include <fstream>

using namespace std;

// TODO add detailed explanation on what the function should do
void generateSeries(int* &arr, int &n, int &m, int &arraySize);
#endif // APPEND_H__
